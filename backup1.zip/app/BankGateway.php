<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class BankGateway extends Model
{
    protected $fillable = ['user_id'];
}
