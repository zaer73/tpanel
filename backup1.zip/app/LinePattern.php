<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class LinePattern extends Model
{
    protected $fillable = ['key', 'pattern'];
}
