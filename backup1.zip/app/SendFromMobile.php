<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class SendFromMobile extends Model
{

	protected $fillable = ['number'];
	
}
