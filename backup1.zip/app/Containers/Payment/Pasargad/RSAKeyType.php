<?php 
namespace App\Containers\Payment\Pasargad;

class RSAKeyType{
	const XMLFile = 0;
	const XMLString = 1;
}