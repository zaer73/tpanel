angular
	.module('inspinia')
	.controller('socketController', function($rootScope, $scope){
		console.log('i');
	});	