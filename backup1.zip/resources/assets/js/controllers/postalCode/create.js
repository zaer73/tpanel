angular
	.module('inspinia')
	.controller('createPostalCodeController', function($rootScope, $scope, $http){
		
		$scope.createPostalCodeURL = 'postal-code';

	});	