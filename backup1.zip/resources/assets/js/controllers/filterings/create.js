angular
	.module('inspinia')
	.controller('createFilteringsController', function($rootScope, $scope){
		
		$scope.createFilteringsURL = 'filterings';

	});	