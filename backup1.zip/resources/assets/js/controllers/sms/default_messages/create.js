angular
	.module('inspinia')
	.controller('createDefaultMessagesController', function($rootScope, $scope){
		
		$scope.createDefaultMessagesURL = 'sms/default-messages';

	});	