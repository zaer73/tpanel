angular
	.module('inspinia')
	.controller('createContactGroupController', function($rootScope, $scope, $http){
		
		$scope.createContactGroupURL = 'contacts/groups';

	});	