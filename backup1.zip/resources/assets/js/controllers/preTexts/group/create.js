angular
	.module('inspinia')
	.controller('createPreTextGroupController', function($rootScope, $scope, $http){
		
		$scope.createPreTextGroupURL = 'pre-texts/group';

	});	