angular
	.module('inspinia')
	.controller('createBlacklistController', function($rootScope, $scope){
		
		$scope.createBlacklistURL = 'blacklist';

	});	