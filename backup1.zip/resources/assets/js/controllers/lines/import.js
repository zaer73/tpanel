angular
	.module('inspinia')
	.controller('importLineController', function($scope){
		
		$scope.importLineURL = 'lines/import';

	});	