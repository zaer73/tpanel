angular
	.module('inspinia')
	.controller('createFAQSController', function($rootScope, $scope){
		
		$scope.createFAQSURL = 'faqs';

	});	