angular
	.module('inspinia')
	.controller('createOccupationsController', function($rootScope, $scope){
		
		$scope.createOccupationsURL = 'occupations';

	});	