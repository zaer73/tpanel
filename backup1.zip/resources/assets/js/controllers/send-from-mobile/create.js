angular
	.module('inspinia')
	.controller('sendFromMobileCreateController', function($scope){
		
		$scope.createSendFromMobileURL = 'send-from-mobile';

	});	