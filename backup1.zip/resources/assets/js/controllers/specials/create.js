angular
	.module('inspinia')
	.controller('createSpecialsController', function($rootScope, $scope){
		
		$scope.createSpecialsURL = 'specials';

	});	