angular
	.module('inspinia')
	.controller('createNewsController', function($rootScope, $scope, $http){
		$scope.createNewsURL = 'news';
	});	