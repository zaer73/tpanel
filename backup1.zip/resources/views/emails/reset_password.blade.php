سلام {{ $inputs['name'] }}
<br><br>
رمز عبور جدید شما: {{ $inputs['password'] }}